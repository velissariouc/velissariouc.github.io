module.exports = {
    verbose: true,
    setupFiles: ['jest-canvas-mock'],
    globals: {
        myCaptcha: null
    }
}
